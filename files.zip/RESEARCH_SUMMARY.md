# HEZBOLLAH SOUTH AMERICA RESEARCH PROJECT
## OFAC SDN Analysis - Initial Findings

**Date:** November 13, 2025  
**Source:** OFAC Specially Designated Nationals List  
**Publication Date:** 11/13/2025  
**Total SDN Records:** 18,336 entities

---

## EXECUTIVE SUMMARY

### Key Findings

1. **Total Hezbollah Entities Identified:** 146
   - Individuals: 119
   - Organizations: 25
   - Entity types: 2

2. **South American Connections:** 3 entities with direct links
   - Colombia: 2 individuals with Colombian nationality/documents
   - Venezuela: 1 individual with Venezuelan address

3. **Critical Gap:** No entities with addresses in Argentina, Brazil, or Paraguay despite known Hezbollah activity in the tri-border area

### What This Means

The limited OFAC presence in the tri-border area suggests:
- Operations are more covert than in other regions
- Individuals may not yet be designated
- Shell companies and intermediaries are being used
- **Your additional sources (blog posts, court docs, news articles) will be essential**

---

## DETAILED FINDINGS

### 1. HEZBOLLAH OFAC DESIGNATIONS

**Program Distribution:**
- SDGT (Specially Designated Global Terrorists): 126 entities
- LEBANON: 17 entities
- IFSR (Iran Freedom and Support Act): 5 entities
- IRGC (Islamic Revolutionary Guard Corps): 4 entities
- FTO (Foreign Terrorist Organizations): 4 entities
- Other programs: 6 entities

**Geographic Distribution (Top Locations):**

*Primary:*
- Lebanon: 126 addresses, 62 nationalities
- Iraq: 18 addresses, 8 nationalities
- Iran: 14 addresses, 4 nationalities

*Secondary:*
- Kuwait: 7 addresses
- Syria: 6 addresses
- United Kingdom: 5 addresses
- Nigeria: 5 addresses

*South America:*
- Colombia: 2 nationalities, 5 ID documents
- Venezuela: 1 address, 1 ID document

### 2. SOUTH AMERICAN ENTITIES - DETAILED PROFILES

#### Entity 1: Salman Raouf SALMAN (UID: 27039)
**Type:** Individual  
**Program:** SDGT (Linked to Hizballah)

**Colombian Connections:**
- Nationality: Colombian
- Passport: AD 059541, AC 128856 (Colombia)
- National ID: 84.049.097 (Colombia)

**Aliases:**
- Salman AL-REDA
- Samuel Salman EL-REDA
- Samwil Salman AL-RIDA
- Salman Raof SALMAN
- Salman Rauf SALMAN
- Salman REMAL
- Andree MARQUEZ

**Research Priority:** HIGH - Multiple Colombian documents, numerous aliases suggesting identity fraud network

---

#### Entity 2: Amer Mohamed Akil RADA (UID: 44499)
**Type:** Individual  
**Program:** SDGT (Linked to Hizballah)

**South American Connections:**
- Nationality: Colombian
- Venezuelan ID: V-28426454
- Colombian Cedula: 67121004582

**Aliases:**
- Amer Muhammad AQEEL

**Research Priority:** HIGH - Dual Colombia-Venezuela presence

---

#### Entity 3: Samer Akil RADA (UID: 44522)
**Type:** Individual  
**Program:** SDGT (Linked to Hizballah)

**South American Connections:**
- Address: Venezuela (city not specified)
- Colombian ID: 179029472

**Aliases:**
- Samer Mohamed Akil RADA
- Samer Mohamed Akil REDA

**Family Connection:** Note "RADA" surname shared with Entity 2 - likely related

**Research Priority:** HIGH - Active Venezuelan address

---

## DATA STRUCTURE OVERVIEW

The OFAC SDN data has been parsed into the following relational structure:

### Core Tables:

1. **entities** - Basic entity information
   - uid (unique identifier)
   - sdn_type (Individual/Entity)
   - first_name, last_name
   - title
   - remarks (often contains program details)

2. **programs** - Sanction program designations
   - entity_uid (links to entities)
   - program (SDGT, LEBANON, FTO, etc.)

3. **aliases** - Also Known As (AKA) names
   - entity_uid
   - aka_uid
   - type (a.k.a., f.k.a., n.k.a.)
   - first_name, last_name
   - category (strong/weak)

4. **addresses** - Physical locations
   - entity_uid
   - address1, address2, address3
   - city, state_province
   - postal_code, country

5. **nationalities** - Citizenship information
   - entity_uid
   - country

6. **dob** - Dates of birth
   - entity_uid
   - date_of_birth

7. **pob** - Places of birth
   - entity_uid
   - place_of_birth

8. **ids** - Identification documents
   - entity_uid
   - id_type (Passport, National ID, etc.)
   - id_number
   - id_country
   - issue_date, expiration_date

---

## NEXT STEPS FOR YOUR RESEARCH

### 1. Data Integration Strategy

**Cross-Reference with Your Sources:**
- Search for the 3 SA entities in your blog posts/PDFs
- Look for business associates, family members
- Search for the aliases in court documents
- Check for corporate connections

**Expand the Network:**
- Identify businesses owned/operated by these individuals
- Map family/associate networks
- Look for shell companies in tri-border area
- Cross-reference with local business registries

### 2. Geographic Analysis

**Focus Areas:**
- Ciudad del Este, Paraguay (major hub)
- Foz do Iguaçu, Brazil
- Puerto Iguazú, Argentina
- Maicao, Colombia (border town)
- Margarita Island, Venezuela (free trade zone)

**Look For:**
- Import/export companies
- Money exchange businesses (casas de cambio)
- Electronics retailers
- Used car dealerships
- Real estate holdings

### 3. Financial Network Mapping

**Key Indicators:**
- Wire transfers to/from Lebanon
- Trade-Based Money Laundering (TBML)
- Over/under-invoicing schemes
- Cigarette smuggling operations
- Counterfeit goods trafficking

### 4. Python Analysis Tools

I've created Python scripts you can use to:
- Parse additional sources
- Match names (including fuzzy matching for aliases)
- Build relationship networks
- Generate visualizations
- Export data for dashboard creation

---

## TECHNICAL NOTES

### Files Created:

**Full SDN Dataset:**
- `sdn_full_entities.csv` - All 18,336 entities
- `sdn_full_programs.csv` - All program designations
- `sdn_full_aliases.csv` - All aliases
- `sdn_full_addresses.csv` - All addresses
- `sdn_full_dob.csv` - Dates of birth
- `sdn_full_pob.csv` - Places of birth
- `sdn_full_nationalities.csv` - Nationalities
- `sdn_full_ids.csv` - ID documents

**Hezbollah Subset:**
- `hezbollah_entities.csv` - 146 Hezbollah entities
- `hezbollah_programs.csv`
- `hezbollah_aliases.csv` - 425 aliases
- `hezbollah_addresses.csv` - 211 addresses
- `hezbollah_dob.csv`, `hezbollah_pob.csv`
- `hezbollah_nationalities.csv`
- `hezbollah_ids.csv` - 521 ID documents

**South America Focus:**
- `hezbollah_southamerica_entities.csv` - 3 entities
- `hezbollah_southamerica_addresses.csv`
- `hezbollah_southamerica_nationalities.csv`
- `hezbollah_southamerica_ids.csv`
- `hezbollah_southamerica_programs.csv`
- `hezbollah_southamerica_aliases.csv`

### Data Quality Notes:

- All UIDs are unique identifiers you can use as primary keys
- Some fields may be null/empty
- Dates are in various formats (will need standardization)
- Country names are standardized
- Aliases have strength ratings (strong/weak)

---

## RECOMMENDATIONS FOR FEDERAL PRESENTATION

### Structure Your Final Product As:

1. **Executive Summary**
   - Key findings
   - Network visualization
   - Risk assessment

2. **Entity Profiles**
   - Individual/organization details
   - Cross-references
   - Activity timeline
   - Evidence documentation

3. **Geographic Analysis**
   - Tri-border area presence
   - Financial flows
   - Network nodes

4. **Supporting Evidence**
   - OFAC documentation
   - Court records
   - News articles
   - Corporate filings

5. **Recommendations**
   - Additional designations needed
   - Investigation targets
   - Monitoring priorities

### Dashboard Elements to Include:

- Interactive network graph
- Geographic heat map
- Timeline of activities
- Financial flow diagrams
- Entity relationship diagrams
- Search/filter functionality
- PDF export capability

---

## CRITICAL OBSERVATIONS

### What We Found:
✓ Comprehensive OFAC baseline (146 entities)  
✓ 3 entities with direct SA connections  
✓ Strong Colombia/Venezuela presence  
✓ Extensive alias networks  
✓ 521 identification documents  

### What We're Missing:
✗ Tri-border area (Argentina/Brazil/Paraguay) presence  
✗ Corporate/business entities in SA  
✗ Financial transaction records  
✗ Associate networks (non-designated)  
✗ Recent activity (last 1-2 years)  

**This is where your additional sources become crucial.**

---

## QUESTIONS TO EXPLORE

1. **For Entity Research:**
   - What businesses are associated with the RADA family?
   - Where is Salman Raouf SALMAN currently located?
   - What is the relationship between Colombian and Venezuelan operations?

2. **For Network Analysis:**
   - Who are the local facilitators in the tri-border area?
   - What legitimate businesses provide cover?
   - How are funds transferred?

3. **For Federal Presentation:**
   - Which entities should be priority targets for new designations?
   - What evidence standards do you need to meet?
   - What format/security level for the final product?

---

## CONTACT FOR FOLLOW-UP

As you work through your other sources, I can help with:
- Parsing PDFs and extracting entity data
- Building name-matching algorithms
- Creating network visualizations
- Designing your database schema
- Developing the dashboard framework
- Statistical analysis
- Report generation

**Next**: Send me samples of your blog post/PDF data and we'll start the cross-referencing process.

---

*This analysis is based on publicly available OFAC SDN data as of November 13, 2025. Additional sources and intelligence will be required for comprehensive coverage of Hezbollah operations in South America.*
